﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace ChatClient
{

    /*
     *  _____ _______         _                      _              
     * |_   _|__   __|       | |                    | |             
     *   | |    | |_ __   ___| |___      _____  _ __| | __  ___ ____
     *   | |    | | '_ \ / _ \ __\ \ /\ / / _ \| '__| |/ / / __|_  /
     *  _| |_   | | | | |  __/ |_ \ V  V / (_) | |  |   < | (__ / / 
     * |_____|  |_|_| |_|\___|\__| \_/\_/ \___/|_|  |_|\_(_)___/___|
     *                                                                                                          
     * IT ZPRAVODAJSTVÍ  <>  PROGRAMOVÁNÍ  <>  HW A SW  <>  KOMUNITA
     * 
     * Tento zdrojový kód je součástí výukových seriálů na 
     * IT sociální síti WWW.ITNETWORK.CZ	
     *	
     * Kód spadá pod licenci prémiového obsahu a vznikl díky podpoře
     * našich členů. Je určen pouze pro osobní užití a nesmí být šířen.
     *
     */

    /// <summary>
    /// Obsahuje logiku pro posílání a přijímání řetězců přes TcpClient
    /// </summary>

    public static class PosilacRetezcu
    {
        /// <summary>
        /// Separátor
        /// </summary>
        public const int separator = 0;

        /// <summary>
        /// Pošle textový řetězec danému klientovi
        /// </summary>
        /// <param name="klient">Klient</param>
        /// <param name="zprava">Řetězec k odeslání</param>
        public static void PosliString(TcpClient klient, string zprava)
        {
            byte[] byteBuffer = Encoding.UTF8.GetBytes(zprava);
            NetworkStream netStream = klient.GetStream();
            netStream.Write(byteBuffer, 0, byteBuffer.Length);
            netStream.Write(new byte[] { separator }, 0, sizeof(byte));
            netStream.Flush();
        }

        /// <summary>
        /// Přijme řetězec od daného klienta
        /// </summary>
        /// <param name="klient">Klient</param>
        /// <returns>Řetězec od klienta</returns>
        public static string PrijmiString(TcpClient klient)
        {
            List<int> buffer = new List<int>();
            NetworkStream stream = klient.GetStream();
            int readByte;
            while ((readByte = stream.ReadByte()) != 0)
            {
                buffer.Add(readByte);
            }
            return Encoding.UTF8.GetString(buffer.Select<int, byte>(b => (byte)b).ToArray(), 0, buffer.Count);
        }

    }
}
